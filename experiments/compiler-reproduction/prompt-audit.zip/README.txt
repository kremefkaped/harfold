Two fresh agent sessions generated the two verifiers from the same positive example. The birch instructions add two sentences about attributing a verdict to the named native test record. One positive example was shown to both; eight additional frozen pairs were withheld. Each verifier matched 9/9 expected outcomes. One session per condition. These files concern recorded test outcomes, not root cause or market adoption.

Replay: python score.py iris, then python score.py birch.
The native TAP/JUnit records were captured on Node v24.14.1. Local machine paths in these copies were replaced by /fixture and both scores were rechecked.
