import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET


TEST = "opens the existing record"
MESSAGE = "record unexpectedly missing"
RESULT = re.compile(
    r"^( *)(ok|not ok) [0-9]+ - " + re.escape(TEST) + r"(\s+#.*)?$"
)
FRAME = re.compile(
    r"(?:at )?(?:async )?(?:[\w$]+\.)*openRecord \((.+):([1-9]\d*):([1-9]\d*)\)"
)


def application_frame(line):
    match = FRAME.fullmatch(line.strip())
    if match and not match[1].startswith(("node:", "internal/")):
        return match.groups()
    return None


def tap_fields(lines, indent):
    """Read scalar values from the result's own Node TAP diagnostic block."""
    if not lines or lines[0] != indent + "---":
        return {}
    fields = {}
    i = 1
    while i < len(lines):
        line = lines[i]
        if line == indent + "...":
            return fields
        field = re.fullmatch(re.escape(indent) + r"([\w]+):\s*(.*)", line)
        if not field or field[1] in fields:
            return {}
        key, value = field.groups()
        i += 1
        continuation = []
        while i < len(lines) and (not lines[i].strip() or lines[i].startswith(indent + "  ")):
            continuation.append(lines[i][len(indent) + 2:])
            i += 1
        if value in {"|", "|-", "|+"}:
            value = "\n".join(continuation)
        elif len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        fields[key] = value
    return {}


def tap_outcome(tap, bad):
    lines = tap.splitlines()
    if not lines or lines[0] != "TAP version 13":
        return None
    if any(line.lstrip().startswith("Bail out!") for line in lines):
        return None
    if not re.search(r"(?m)^1\.\.[1-9]\d*\r?$", tap):
        return None
    for label in ("tests", "fail" if bad else "pass"):
        counts = re.findall(r"(?m)^# " + label + r" (\d+)\r?$", tap)
        if counts and (len(counts) != 1 or int(counts[0]) == 0):
            return None
    matches = [(i, m) for i, line in enumerate(lines) if (m := RESULT.fullmatch(line))]
    if len(matches) != 1:
        return None
    i, result = matches[0]
    if result[3] or result[2] != ("not ok" if bad else "ok"):
        return None
    if not bad:
        return True
    fields = tap_fields(lines[i + 1:], result[1] + "  ")
    if (fields.get("failureType") != "testCodeFailure"
            or fields.get("name") != "AssertionError"
            or fields.get("code") != "ERR_ASSERTION"
            or fields.get("error", "").split("\n", 1)[0] != MESSAGE):
        return None
    return application_frame(fields.get("stack", "").split("\n", 1)[0])


def test_cases(root):
    """Only suite containers own cases. Output and diagnostics can contain XML."""
    if root.tag in {"testsuites", "testsuite"}:
        for child in root:
            if child.tag == "testcase":
                yield child
            elif child.tag in {"testsuites", "testsuite"}:
                yield from test_cases(child)


def junit_outcome(xml, bad):
    root = ET.fromstring(xml)
    cases = [case for case in test_cases(root) if case.get("name") == TEST]
    if len(cases) != 1:
        return None
    case = cases[0]
    if (any(k in case.attrib for k in ("skipped", "disabled", "todo", "error"))
            or any(c.tag not in {"failure", "system-out", "system-err", "properties"} for c in case)):
        return None
    failures = case.findall("failure")
    if not bad:
        return True if (not failures and "failure" not in case.attrib
                        and case.get("status", "passed") in {"passed", "run"}) else None
    if len(failures) != 1 or case.get("status", "failed") not in {"failed", "failure", "run"}:
        return None
    failure = failures[0]
    if (len(failure) or failure.get("type") != "testCodeFailure"
            or failure.get("message", "").splitlines()[:1] != [MESSAGE]
            or case.get("failure", MESSAGE).splitlines()[:1] != [MESSAGE]):
        return None
    lines = (failure.text or "").splitlines()
    causes = [i for i, line in enumerate(lines) if line.startswith("  cause: ")]
    if len(causes) != 1 or lines[causes[0]] != "  cause: AssertionError [ERR_ASSERTION]: " + MESSAGE:
        return None
    for line in lines[causes[0] + 1:]:
        if line.startswith("      at "):
            return application_frame(line.removesuffix(" {"))
    return None


def establishes(path, bad):
    evidence = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if not isinstance(evidence, dict) or type(evidence.get("exit")) is not int:
        return False
    if evidence["exit"] < 0 or (evidence["exit"] != 0) != bad:
        return False
    if not all(isinstance(evidence.get(k), str) for k in ("tap", "junit")):
        return False
    tap = tap_outcome(evidence["tap"], bad)
    return tap is not None and tap == junit_outcome(evidence["junit"], bad)


if __name__ == "__main__":
    try:
        confirmed = len(sys.argv) == 3 and establishes(sys.argv[1], False) and establishes(sys.argv[2], True)
    except (OSError, ValueError, ET.ParseError, RecursionError, LookupError):
        confirmed = False
    print("confirmed" if confirmed else "insufficient")
