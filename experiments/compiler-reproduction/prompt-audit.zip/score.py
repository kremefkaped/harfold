"""Replay frozen native records through one independently generated verifier."""
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FROZEN = '2ce4734825adb48d005eb7a2b59e0abe255fdf4615c53dbdcb89088dad5d229b'
raw = (ROOT/'locked.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == FROZEN
study = json.loads(raw)
seat = sys.argv[1]
assert seat in ('iris', 'birch')
results = []
with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
    good_file = Path(tmp)/'control.json'
    bad_file = Path(tmp)/'candidate.json'
    for good,bad,expected in study['pairs']:
        good_file.write_text(json.dumps(study['samples'][good]), encoding='utf8')
        bad_file.write_text(json.dumps(study['samples'][bad]), encoding='utf8')
        proc = subprocess.run([sys.executable,'-B','verify.py',str(good_file),str(bad_file)],
                              cwd=ROOT/seat,timeout=8,capture_output=True,text=True,encoding='utf8')
        result = proc.stdout.strip()
        label = 'confirmed' if expected else 'insufficient'
        results.append({'good':good,'bad':bad,'expected':label,'returned':result,
                        'matched':proc.returncode == 0 and result == label})
out = {'cases':len(results), 'matched':sum(r['matched'] for r in results),'results':results}
(ROOT/(seat+'-scores.json')).write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps(out))
