import json
import re
import sys
import xml.etree.ElementTree as ET


NAME = "opens the existing record"
MESSAGE = "record unexpectedly missing"
RESULT = re.compile(r"^( *)(not ok|ok)\s+\d+\s+-\s+(.*?)\s*$")
DIRECTIVE = re.compile(r"\s+#\s*(?:skip|todo)\b", re.I)
FRAME = re.compile(r"(?:async )?(?:[\w$]+\.)*openRecord \((?!node:)(.+:\d+:\d+)\)")


def first_line(value):
    return value.strip().split("\n", 1)[0].strip()


def at_application_function(lines):
    for line in lines:
        frame = line.strip().removeprefix("at ")
        if not frame:
            continue
        if re.fullmatch(r".*\(node:[^)]+\)|node:\S+", frame):
            continue
        return FRAME.fullmatch(frame) is not None
    return False


def diagnostic(lines, start, indent):
    prefix = indent + "  "
    if start >= len(lines) or lines[start] != prefix + "---":
        return {}
    fields = {}
    field = None
    for line in lines[start + 1:]:
        if line == prefix + "...":
            return fields
        if line.startswith(prefix + "  ") and field:
            fields[field] += "\n" + line[len(prefix) + 2:]
            continue
        match = re.fullmatch(re.escape(prefix) + r"(\w+):\s*(.*)", line)
        if not match:
            if line.strip():
                raise ValueError("incomplete test diagnostic")
            continue
        field, value = match.groups()
        if field in fields:
            raise ValueError("duplicate diagnostic field")
        if value in ("|-", "|", "|+", ">-", ">", ">+"):
            value = ""
        elif len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        fields[field] = value
    raise ValueError("unterminated test diagnostic")


def tap_evidence(tap, failed):
    lines = tap.splitlines()
    matches = []
    diagnostic_end = None
    for i, line in enumerate(lines):
        if diagnostic_end is not None:
            if line == diagnostic_end:
                diagnostic_end = None
            continue
        marker = re.fullmatch(r"( +)---", line)
        if marker:
            diagnostic_end = marker.group(1) + "..."
            continue
        if re.match(r"^\s*Bail out!|^1\.\.0(?:\s|$)", line, re.I):
            return False
        match = RESULT.fullmatch(line)
        if match:
            indent, outcome, label = match.groups()
            if DIRECTIVE.split(label, 1)[0] == NAME:
                matches.append((i, indent, outcome, label))
        count = re.fullmatch(r"# (tests|pass|fail) (\d+)", line)
        if count:
            key, number = count.groups()
            if key in ("tests", "fail" if failed else "pass") and int(number) == 0:
                return False
            if not failed and key == "fail" and int(number):
                return False
    if diagnostic_end is not None or len(matches) != 1:
        return False
    i, indent, outcome, label = matches[0]
    if label != NAME or (outcome == "not ok") != failed:
        return False
    fields = diagnostic(lines, i + 1, indent)
    if fields.get("type", "test") != "test":
        return False
    if not failed:
        return not any(k in fields for k in ("failureType", "error", "stack"))
    return (fields.get("failureType", "testCodeFailure") == "testCodeFailure"
            and fields.get("code") == "ERR_ASSERTION"
            and fields.get("name", "AssertionError") == "AssertionError"
            and first_line(fields.get("error", "")) == MESSAGE
            and at_application_function(fields.get("stack", "").splitlines()))


def junit_evidence(xml, failed):
    root = ET.fromstring(xml)
    for element in root.iter():
        element.tag = element.tag.rsplit("}", 1)[-1]
    if root.tag not in ("testsuites", "testsuite"):
        return False
    suites = [root]
    cases = []
    while suites:
        suite = suites.pop()
        suites.extend(suite.findall("testsuite"))
        cases.extend(c for c in suite.findall("testcase") if c.get("name") == NAME)
    if len(cases) != 1:
        return False
    case = cases[0]
    if any(c.tag in ("skipped", "error", "todo", "cancelled") for c in case):
        return False
    if any(k in case.attrib for k in ("skipped", "error", "todo", "cancelled")):
        return False
    if case.get("status", "").lower() in ("skipped", "notrun", "disabled", "cancelled", "todo"):
        return False
    failures = case.findall("failure")
    if not failed:
        return not failures and "failure" not in case.attrib
    if len(failures) != 1 or first_line(case.get("failure", MESSAGE)) != MESSAGE:
        return False
    failure = failures[0]
    if failure.get("type", "testCodeFailure") not in ("testCodeFailure", "AssertionError"):
        return False
    if first_line(failure.get("message", "")) != MESSAGE:
        return False
    body = (failure.text or "").strip()
    if not body:
        return True  # The TAP diagnostic supplies the assertion and stack.
    cause = re.search(r"(?m)^\s*cause:\s*(.+)$", body)
    if cause:
        if cause.group(1).strip() != f"AssertionError [ERR_ASSERTION]: {MESSAGE}":
            return False
        body = body[cause.end():]
    frames = re.findall(r"(?m)^[ \t]*at (.+)$", body)
    return not frames or at_application_function(frames)


def check(path, failed):
    with open(path, encoding="utf-8-sig") as stream:
        run = json.load(stream)
    return (isinstance(run, dict) and type(run.get("exit")) is int
            and (run["exit"] != 0) == failed
            and isinstance(run.get("tap"), str) and isinstance(run.get("junit"), str)
            and tap_evidence(run["tap"], failed) and junit_evidence(run["junit"], failed))


if __name__ == "__main__":
    try:
        confirmed = len(sys.argv) == 3 and check(sys.argv[1], False) and check(sys.argv[2], True)
    except (OSError, ValueError, LookupError, RecursionError, ET.ParseError):
        confirmed = False
    print("confirmed" if confirmed else "insufficient")
