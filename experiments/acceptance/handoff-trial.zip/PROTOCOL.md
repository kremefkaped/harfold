# Preregistered handoff and locked outcomes

Two new agents receive identical code, known-good and known-bad captures, issue brief, CLI implementation and ordinary Markdown report. The second workspace also receives Harfold's CLI-derived JSON syntax contract and generated repair prompt, using the original broken capture and the independently known broken product view. Both materials use Harfold v0.1.0 commit 9d36d6ab9fb98d6195a7b2d10de1d84bef4b27e4. The order of fixed 0.22.0 vs broken 0.21.0 is a good/bad comparison.

Seats cannot consult each other, the supervisor directory, other chats, upstream fixes or outside information. Their instructions and task budgets must match. The machine has Python with AnyIO, Uvicorn and Playwright, installed Chrome, Git and Node. Concurrent browser runs resolve checkout.test against separate ephemeral loopback ports. Agents get their initial directory and no further hints. One run per condition is descriptive; the same runner pair and open-source case cannot estimate causal effects or average speedups.

The only change to source HAR inputs is replacing the original loopback host:port string with checkout.test, consistently across the entire JSON. Both seats receive byte-identical inputs. The candidate recorder uses a browser host resolver to record that very origin from real HTTP. Python imports the real Starlette 0.21.0 middleware from the task directory. There is no other version of the middleware in either seat.

The primary engineering outcome is strict. All nine cases below must pass, the independently rerun live product view must display Mug × 2, and the change must respect the scope (edit Python application/library files under starlette/ or add tests under tests/). A current HAR JSON syntax verdict is measured for both seats; it is neither a general behavior oracle nor a substitute for the tests. Record the 9-case vector and source-integrity result even on partial failures. Inspect each agent's final response for observed commands and evidence, and record time separately; do not convert the notes into an after-the-fact quality score.

Locked hidden cases:

1. Already gzip-encoded JSON retains its exact wire bytes and parses to the original object with one decode.
2. Already gzip-encoded JSON delivered in chunks retains its bytes and final completion.
3. An upstream deflate-encoded body keeps the deflate coding and its content when the client accepts gzip or deflate.
4. A sufficiently large, unencoded response is compressed once, sets the appropriate content length and Vary, and decodes to the original bytes.
5. A small, unencoded response remains unchanged below the threshold.
6. A client that requests identity receives the original uncompressed large body.
7. Streaming unencoded data is compressed once, with ordered body data, no stale Content-Length and a terminal frame.
8. An already gzip-encoded response for a client with no explicit Accept-Encoding preserves the upstream header and bytes.
9. An empty unencoded body completes unchanged.

Every HTTP case additionally preserves the status, an unrelated application header and one start event before body events. All candidate inputs outside the allowed paths are compared to the initial manifest. The grader uses distinct URL and JSON product values to detect fixture-specific repairs. Results are calibrated against the untouched real 0.21.0 middleware and the published 0.22.0 middleware, outside the seats.

