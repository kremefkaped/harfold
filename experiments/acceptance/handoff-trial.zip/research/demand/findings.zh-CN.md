# 三个前端项目如何索要复现材料

截至北京时间 2026 年 11 月 10 日 11:13:48，按事先固定的 [取样规则](protocol.md) 提取 12 个仍带指定复现标签的 issue，包含所有状态，每仓库取创建时间最近的 4 条。固定样本号、日期、状态、原始链接及已读评论数见 [selection.json](selection.json)。逐项读了报告及其公开评论，没有联系作者。

**12 条中，明确索要 HAR 的为 0 条。** 报告中有 1 条描述了可以用 HAR 直接核查的具体 HTTP 现象：Astro 在开发模式多发了一个 CSP 响应头。报告者已经提供更小的 curl 验证方式，仓库回复索要可运行的项目。Harfold 现有规则不会检验 CSP 头。[原始报告和回复](https://github.com/withastro/astro/issues/18285#issuecomment-6037613292)

主要分类互斥：1 条是具体 HTTP 观察（H），10 条是源码、构建、运行环境或 DOM 的复现材料（R），1 条无法确定具体技术对象（U）。H 并不代表需求方愿意用 HAR；R 优先反映材料或技术问题，有些报告本身仍然十分简略。表中用 GitHub 的 MEMBER 身份标明有据可查的团队成员。机器人、模板化回复和普通参与者单列。

| 报告 | 主类 | 报告者观察、索要的材料与依据 |
| --- | --- | --- |
| [Vite #23145](https://github.com/vitejs/vite/issues/23145) | R | CommonJS 默认导入的值是对象。报告者补了多段源码和构建命令后，MEMBER 仍明确要求 GitHub 仓库或 StackBlitz，以便直接运行。[成员回复](https://github.com/vitejs/vite/issues/23145#issuecomment-5200303047) |
| [Vite #23030](https://github.com/vitejs/vite/issues/23030) | R | Vitest 浏览器模式报缺少模块导出。CONTRIBUTOR 在提交的项目分支试跑两个版本并调整依赖预打包配置，报告者后来确认有效。另有机器人索要最小项目。错误中的模块 URL 不能证明请求失败。[贡献者实验](https://github.com/vitejs/vite/issues/23030#issuecomment-5066640817) |
| [Vite #22971](https://github.com/vitejs/vite/issues/22971) | R | 报告者缺的是构建钩子中逐次引用的 query 信息。评论指出最终 HTML 仍带 query；这是无团队成员标记的参与者解释。机器人索要最小仓库。[钩子和输出的区别](https://github.com/vitejs/vite/issues/22971#issuecomment-5010560872) · [机器人请求](https://github.com/vitejs/vite/issues/22971#issuecomment-5030588920) |
| [Vite #22937](https://github.com/vitejs/vite/issues/22937) | R | 具体问题是工作区目录、环境文件与配置加载。机器人索要最小项目。后来报告者提出配置缓存的解释，不能据此推断存在 HTTP 缓存问题。[机器人请求](https://github.com/vitejs/vite/issues/22937#issuecomment-4975992984) |
| [Next.js #92888](https://github.com/vercel/next.js/issues/92888) | R | 静态构建时路由参数缺失。MEMBER 实际点开链接，发现最终提供的项目是空模板后关闭。讨论中的 404 指复现链接，与产品缺陷无关。[成员核查](https://github.com/vercel/next.js/issues/92888#issuecomment-4263140972) |
| [Next.js #85550](https://github.com/vercel/next.js/issues/85550) | R | 报告只有开发命令反复报错，无法判断故障对象；但 MEMBER 明确要求提供有效仓库，故按所需材料归 R。[成员请求](https://github.com/vercel/next.js/issues/85550#issuecomment-3467834060) |
| [Next.js #84784](https://github.com/vercel/next.js/issues/84784) | R | 从运行时崩溃进一步具体化为 tooltip 的视觉位置、状态和依赖版本。MEMBER 要求提交含故障依赖版本的仓库。另一位贡献者猜测 service worker 或缓存可能相关，未观察到请求异常。[成员请求](https://github.com/vercel/next.js/issues/84784#issuecomment-3397812463) · [贡献者保留意见](https://github.com/vercel/next.js/issues/84784#issuecomment-3419067998) |
| [Next.js #84050](https://github.com/vercel/next.js/issues/84050) | U | 报告称开发与调试变慢及崩溃，没有具体动作、请求或可核查的环境现象。机器人通用模板要求可运行项目，缺少针对这一报告的技术定位或成员反馈。[机器人模板](https://github.com/vercel/next.js/issues/84050#issuecomment-3319317265) |
| [Astro #18285](https://github.com/withastro/astro/issues/18285) | H | 报告给出开发服务器的 CSP 响应头、浏览器拦截内联样式的错误、预期无该头以及 curl 命令。HAR 能直接检查响应头；定位源码中的判断逻辑仍需配置和复现。CONTRIBUTOR 身份的模板化回复索要 GitHub 或 StackBlitz。[复现请求](https://github.com/withastro/astro/issues/18285#issuecomment-6037613292) |
| [Astro #18276](https://github.com/withastro/astro/issues/18276) | R | 作者想让 action 返回带自定义头的 401，报告描述服务端异常被框架捕获，未给出客户端实收的状态或头。自动分诊明确跳过复现；其 500 推断未经实测。模板化回复索要项目。仅当补录后才可能从网络观察结果，未计 H。[分诊记录](https://github.com/withastro/astro/issues/18276#issuecomment-6026736135) · [复现请求](https://github.com/withastro/astro/issues/18276#issuecomment-6037616659) |
| [Astro #18171](https://github.com/withastro/astro/issues/18171) | R | service worker 注册的 Promise 返回 undefined 引发异常。机器人报告使用模拟 DOM 和注册函数桩重现，又有参与者指出上游修复。需要的是可控制的 JS 返回值。[分诊方式](https://github.com/withastro/astro/issues/18171#issuecomment-5884830836) · [上游修复线索](https://github.com/withastro/astro/issues/18171#issuecomment-5968413252) |
| [Astro #18092](https://github.com/withastro/astro/issues/18092) | R | 报告定位到 Netlify 工具调用 Deno 的命令行参数，所需材料涉及版本和运行环境。自动分诊跳过，模板化回复索要 GitHub 或 StackBlitz。[分诊记录](https://github.com/withastro/astro/issues/18092#issuecomment-5770009336) · [复现请求](https://github.com/withastro/astro/issues/18092#issuecomment-5847782500) |

**适用边界。** 三个仓库处理的是框架问题，且标签本身偏向欠缺可运行复现的报告。现存标签不能还原曾加标、后来移除的全部历史。12 条恰好全已关闭，创建日期跨度为 2025-09-22 至 2026-10-07。标签来源、时间跨度、关闭流程与模板化回复都限制外推。把 #84050 仅按机器人索要的材料归 R，会变成 11 R、0 U，仍是 0 条明确要 HAR。不能用这里的比例估算所有线上故障、性能团队或付费用户群，也不能把该样本视为产品试用。
