import asyncio
import copy
import gzip
import unittest
import zlib

from starlette.middleware.gzip import GZipMiddleware


def exchange(headers, chunks, accept_encoding=b"gzip", minimum_size=10):
    messages = [{"type": "http.response.start", "status": 200, "headers": headers}]
    for index, chunk in enumerate(chunks):
        messages.append({
            "type": "http.response.body", "body": chunk, "more_body": index + 1 < len(chunks)
        })
    sent = []

    async def app(scope, receive, send):
        for message in copy.deepcopy(messages):
            await send(message)

    async def send(message):
        sent.append(message)

    scope = {"type": "http", "headers": [(b"accept-encoding", accept_encoding)]}
    asyncio.run(GZipMiddleware(app, minimum_size)(scope, None, send))
    return messages, sent


class GZipTests(unittest.TestCase):
    def test_existing_encoding_preserves_headers_and_chunks(self):
        for encoding, compress in [(b"gzip", gzip.compress), (b"deflate", zlib.compress)]:
            encoded = compress(b"preserve this representation")
            headers = [
                (b"content-encoding", encoding),
                (b"content-length", str(len(encoded)).encode()),
                (b"vary", b"Origin"),
            ]
            for chunks in [[encoded], [encoded[:3], encoded[3:], b""]]:
                with self.subTest(encoding=encoding, chunks=len(chunks)):
                    original, sent = exchange(headers, chunks, accept_encoding=b"gzip, deflate")
                    self.assertEqual(original, sent)

    def test_unencoded_responses_still_compress(self):
        body = b"ordinary response"
        for chunks in [[body], [body[:2], body[2:]]]:
            with self.subTest(chunks=len(chunks)):
                _, sent = exchange([(b"content-length", str(len(body)).encode())], chunks)
                headers = dict(sent[0]["headers"])
                encoded = b"".join(message["body"] for message in sent[1:])
                self.assertEqual(headers[b"content-encoding"], b"gzip")
                self.assertEqual(headers[b"vary"], b"Accept-Encoding")
                self.assertEqual(gzip.decompress(encoded), body)
                if len(chunks) == 1:
                    self.assertEqual(headers[b"content-length"], str(len(encoded)).encode())
                else:
                    self.assertNotIn(b"content-length", headers)

    def test_small_response_and_identity_client(self):
        for body, accepted in [(b"small", b"gzip"), (b"ordinary response", b"identity")]:
            with self.subTest(body=body, accepted=accepted):
                original, sent = exchange([], [body], accepted)
                self.assertEqual(original, sent)
