import asyncio
import gzip
import unittest
import zlib

from starlette.middleware.gzip import GZipMiddleware


def respond(parts, headers, accept_encoding=b"gzip"):
    async def app(scope, receive, send):
        await send({"type": "http.response.start", "status": 200, "headers": headers.copy()})
        for index, part in enumerate(parts):
            await send({"type": "http.response.body", "body": part, "more_body": index + 1 < len(parts)})

    messages = []

    async def send(message):
        messages.append(message)

    scope = {"type": "http", "headers": [(b"accept-encoding", accept_encoding)]}
    asyncio.run(GZipMiddleware(app, minimum_size=8)(scope, None, send))
    return messages


class GZipTests(unittest.TestCase):
    def test_existing_encoding_preserves_headers_and_each_body_message(self):
        for encoding, compress in [(b"gzip", gzip.compress), (b"deflate", zlib.compress)]:
            encoded = compress(b"the upstream representation")
            headers = [(b"content-encoding", encoding), (b"content-length", str(len(encoded)).encode())]
            for parts in [[encoded], [encoded[:8], encoded[8:], b""]]:
                with self.subTest(encoding=encoding, parts=len(parts)):
                    self.assertEqual(respond(parts, headers), respond(parts, headers, b"identity"))

    def test_plain_response_is_compressed_and_decodes_once(self):
        for parts in [[b"hello world"], [b"hello", b" world"]]:
            with self.subTest(parts=len(parts)):
                start, *bodies = respond(parts, [(b"content-length", b"11")])
                headers = dict(start["headers"])
                encoded = b"".join(message["body"] for message in bodies)
                self.assertEqual(headers[b"content-encoding"], b"gzip")
                self.assertEqual(headers[b"vary"], b"Accept-Encoding")
                self.assertEqual(gzip.decompress(encoded), b"hello world")
                if len(parts) == 1:
                    self.assertEqual(int(headers[b"content-length"]), len(encoded))
                else:
                    self.assertNotIn(b"content-length", headers)

    def test_small_response_and_identity_client_receive_original_bytes(self):
        for body, accept_encoding in [(b"hi", b"gzip"), (b"hello world", b"identity")]:
            with self.subTest(body=body, accept_encoding=accept_encoding):
                start, message = respond([body], [], accept_encoding)
                self.assertEqual(start["headers"], [])
                self.assertEqual(message["body"], body)
